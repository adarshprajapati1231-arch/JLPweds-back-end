# Backend (Express + Supabase)
- Start: npm start (listens on BACKEND_PORT)
- Seed demo vendors: npm run seed
- Ensure .env is kept private and contains SUPABASE_SERVICE_ROLE_KEY
